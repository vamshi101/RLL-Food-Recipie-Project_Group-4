export class review {
    id: string;
    recipiename: string;
    rating: string;
    review: string;
}