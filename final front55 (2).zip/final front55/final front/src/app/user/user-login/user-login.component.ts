import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserLoginService } from './user-login.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  userForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private userLoginService: UserLoginService,
    private router: Router,
    private route: ActivatedRoute){ }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group(
      {
        'id': [null],
        "email": [],
        "name": [],
        "password": [],
        "phone": [],
      }
    );
  }

  onclk() {
    this.router.navigate(['/userreg']);
  }

  onUserLogIn() {
    this.userLoginService.checkUserLoginDetails(this.userForm.value).subscribe(
      response => {
        console.log(response);
        if (response) {
          localStorage.setItem('userlog', JSON.stringify(this.userForm.value));
          this.router.navigate(['/userdash']);
        } else {
          alert("no user exists with the given details. please register.")
        }
      }
    )
  }
  logOut() {
    localStorage.removeItem('userlog');
    this.router.navigate(['/']);
}
}